import { Router } from 'express';
const router = Router();

// Placeholder Route
router.get('/', (req, res) => {
  res.json({ message: "Feature coming soon" });
});

export default router;